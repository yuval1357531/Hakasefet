import './globals.css'

export const metadata = {
  title: 'הכספת | ג׳אוריוס',
  description: 'הכספת של ג׳אוריוס – מרחב אישי לשינוי חיים',
}

export default function RootLayout({ children }) {
  return (
    <html lang="he" dir="rtl">
      <body>{children}</body>
    </html>
  )
}
