'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  async function handleLogin(e) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      setError('שם משתמש או סיסמה לא נכונים')
      setLoading(false)
    } else {
      router.push('/dashboard')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      {/* Background glow */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-vault-gold/5 rounded-full blur-[120px]" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo / Brand */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-vault-card border border-vault-gold/30 gold-glow mb-6">
            <span className="text-vault-gold text-3xl">🔐</span>
          </div>
          <h1 className="text-3xl font-bold text-vault-text mb-2">הכספת</h1>
          <p className="text-vault-muted text-lg">ברוכים הבאים חזרה</p>
        </div>

        {/* Login Form */}
        <div className="vault-card gold-glow">
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-vault-muted text-sm mb-2">אימייל</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="vault-input"
                placeholder="your@email.com"
                dir="ltr"
                required
              />
            </div>

            <div>
              <label className="block text-vault-muted text-sm mb-2">סיסמה</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="vault-input"
                placeholder="••••••••"
                dir="ltr"
                required
              />
            </div>

            {error && (
              <p className="text-red-400 text-sm text-center">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="vault-btn w-full text-center disabled:opacity-50"
            >
              {loading ? 'נכנסים...' : 'כניסה לכספת'}
            </button>
          </form>
        </div>

        <p className="text-center text-vault-muted text-sm mt-6">
          Jaurius © {new Date().getFullYear()}
        </p>
      </div>
    </div>
  )
}
